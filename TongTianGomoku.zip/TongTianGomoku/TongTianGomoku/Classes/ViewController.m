
#import <WebKit/WebKit.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "ViewController.h"

@interface ViewController () <WKUIDelegate, WKNavigationDelegate, GADInterstitialDelegate>
@property(nonatomic, strong) WKWebView *webView;
@property(nonatomic, strong) WKWebViewConfiguration *config;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) NSInteger timeLeft;
@property(nonatomic, assign) NSInteger timelength;
@property(nonatomic, assign) BOOL isAdIdFirstLoad;
@property(nonatomic, strong) GADInterstitial *interstitial;
@property(nonatomic, strong) NSArray<NSString *> *interstitialAdIds;
@end

@implementation ViewController

- (BOOL)shouldAutorotate {
    return NO;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        _timelength = 1200;
        _isAdIdFirstLoad = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[self colorWithHexString:(@"#3121B5")]];
    
    [self viewDidLoadRequestWebHtml];
    
    [self beginNewGoogleAds];
}

- (void)beginNewGoogleAds
{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    [self generateInterstitial];
    self.timeLeft = self.timelength;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                                  target:self
                                                selector:@selector(decrementTimeLeft:)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)generateInterstitial
{
    NSMutableArray<NSString *> *googleAdIdArray = [NSMutableArray arrayWithArray:self.interstitialAdIds];
    if ([googleAdIdArray count] > 1) {
        for (NSUInteger i = [googleAdIdArray count] - 1; i > 0; --i) {
            [googleAdIdArray exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
        }
    }
    NSString *identifier = [googleAdIdArray firstObject];
    if (identifier.length > 0) {
        self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:identifier];
        [self.interstitial setDelegate:self];
        [self.interstitial loadRequest:[GADRequest request]];
    }
}

- (void)presentToShowGoogleAds
{
    [self.timer invalidate];
    self.timer = nil;
    if (self.interstitial.isReady) {
        [self.interstitial presentFromRootViewController:self];
    } else {
        [self beginNewGoogleAds];
    }
}

- (void)decrementTimeLeft:(NSTimer *)timer
{
    self.timeLeft --;
    if (self.timeLeft <= 0) {
        [self presentToShowGoogleAds];
    }
}

- (void)interstitialDidReceiveAd:(GADInterstitial *)ad {
    if (self.isAdIdFirstLoad) {
        self.timeLeft = 0;
        self.isAdIdFirstLoad = NO;
    }
}

- (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error {
    if (self.isAdIdFirstLoad) {
        self.isAdIdFirstLoad = NO;
        [self performSelector:@selector(showMyGameContent) withObject:self afterDelay:0.0f];
    }
}

- (void)interstitialWillPresentScreen:(nonnull GADInterstitial *)ad
{
    [self performSelector:@selector(showMyGameContent) withObject:self afterDelay:1.5f];
}

- (void)interstitialDidDismissScreen:(GADInterstitial *)interstitial {
    [self beginNewGoogleAds];
}

- (void)showMyGameContent
{
    self.webView.hidden = self.isAdIdFirstLoad;
}


#pragma mark - StartLoadRequestWebHtml

- (void)viewDidLoadRequestWebHtml
{
    NSString *urlString = @"tietactoe/index.html";
    NSURL *baseURL = [NSURL URLWithString:urlString relativeToURL:[[NSBundle mainBundle] bundleURL]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:baseURL];
    [self.webView loadRequest:request];
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    self.webView.hidden = YES;
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    self.webView.hidden = NO;
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    self.webView.hidden = NO;
}

- (WKWebView *)webView
{
    if (!_webView) {
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:self.config];
        _webView.navigationDelegate = self;
        _webView.UIDelegate = self;
        _webView.allowsBackForwardNavigationGestures = NO;
        _webView.scrollView.bounces = YES;
        _webView.hidden = YES;
        [self.view addSubview:_webView];
    }
    return _webView;
}

- (WKWebViewConfiguration *)config
{
    if (!_config) {
        _config = [[WKWebViewConfiguration alloc] init];
        _config.allowsInlineMediaPlayback = YES;
        if (@available(iOS 9.0, *)) {
            _config.allowsPictureInPictureMediaPlayback = YES;
        }
        _config.allowsInlineMediaPlayback = YES;
        _config.allowsAirPlayForMediaPlayback = YES;
        if (@available(iOS 10.0, *)) {
            _config.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeAll;
        }
    }
    return _config;
}

- (NSArray<NSString *> *)interstitialAdIds
{
    if (!_interstitialAdIds) {
        _interstitialAdIds = @[
            @"ca-app-pub-3574624433847272/4073134502",
            @"ca-app-pub-3574624433847272/9652764248"
        ];
    }
    return _interstitialAdIds;
}


#pragma mark - Private

- (UIColor*)colorWithHexString:(NSString*)stringToConvert
{
    NSString*cString=[[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if([cString length]< 6)
        return [UIColor whiteColor];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor whiteColor];
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

@end
